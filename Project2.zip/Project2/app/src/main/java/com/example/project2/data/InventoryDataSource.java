package com.example.project2.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.project2.data.helpers.SqlDbHelper;
import com.example.project2.data.model.SqlDbContract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Date;

public class InventoryDataSource {
    private SqlDbHelper dbHelper;

    public InventoryDataSource(Context context){
        dbHelper = new SqlDbHelper(context);
    }

    public Cursor queryInventoryDatabase(String[] projection, String selection, String[] selectionArgs, String sortOrder){
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        return db.query(
                SqlDbContract.InventoryEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );
    }

    public long insertInventoryData(String name, String type, int count){
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_NAME, name);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_TYPE, type);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT, count);
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_DATE, java.text.DateFormat.getDateTimeInstance().format(new Date()));

        return db.insert(SqlDbContract.InventoryEntry.TABLE_NAME, null, values);
    }

    public boolean updateInventoryData(String productId, String newCount){
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT, newCount);
        String selection = SqlDbContract.InventoryEntry._ID + " LIKE ?";
        String[] selectionArgs = {productId};

        return db.update(SqlDbContract.InventoryEntry.TABLE_NAME, values, selection, selectionArgs) > 0;
    }

    public boolean deleteInventoryData(String productId){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = SqlDbContract.InventoryEntry._ID + " LIKE ?";
        String[] selectionArgs = {productId};

        return db.delete(SqlDbContract.InventoryEntry.TABLE_NAME, selection, selectionArgs) > 0;
    }

    public boolean deleteAllInventoryData(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db.delete(SqlDbContract.InventoryEntry.TABLE_NAME, null, null) > 0;
    }
}