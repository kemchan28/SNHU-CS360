package com.example.project2.data.model;

import android.provider.BaseColumns;

public final class SqlDbContract {
    private SqlDbContract(){

    }
    public static class AuthenticationEntry implements BaseColumns{
        public static final String TABLE_NAME = "authentication";
        public static final String COLUMN_NAME_DISPLAY_NAME = "display_name";
        public static final String COLUMN_NAME_USERNAME = "username";
        public static final String COLUMN_NAME_PASSWORD = "password";
        public static final String COLUMN_NAME_LAST_LOGIN = "last_login";

    }

    public static class InventoryEntry implements BaseColumns{
        public static final String TABLE_NAME = "inventory";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_TYPE = "type";
        public static final String COLUMN_NAME_COUNT = "count";
        public static final String COLUMN_NAME_DATE = "dateAdded";
    }
}
