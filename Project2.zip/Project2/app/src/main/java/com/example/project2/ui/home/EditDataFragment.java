package com.example.project2.ui.home;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.project2.R;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;

public class EditDataFragment extends Fragment {
    private EditDataViewModel editDataViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        editDataViewModel =
                new ViewModelProvider(this).get(EditDataViewModel.class);
        editDataViewModel.InitializeDataProvider(getContext());
        View root = inflater.inflate(R.layout.fragment_edit_data, container, false);

        String editId = EditDataFragmentArgs.fromBundle(getArguments()).getItemId();
        String editCount = EditDataFragmentArgs.fromBundle(getArguments()).getItemCount();

        EditText productCountEditText = root.findViewById(R.id.count);
        productCountEditText.setText(editCount);
        Button submitButton = root.findViewById(R.id.Add);

        editDataViewModel.getEditDataFormState().observe(getViewLifecycleOwner(), new Observer<EditDataFormState>() {
            @Override
            public void onChanged(@Nullable EditDataFormState editDataFormState) {
                if (editDataFormState == null) {
                    return;
                }
                submitButton.setEnabled(editDataFormState.isDataValid());
                if (editDataFormState.getCountError() != null) {
                    productCountEditText.setError(getString(editDataFormState.getCountError()));
                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                editDataViewModel.AddDataDataChanged(productCountEditText.getText().toString());
            }
        };

        productCountEditText.addTextChangedListener(afterTextChangedListener);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    editDataViewModel.UpdateRecordCount(editId, productCountEditText.getText().toString());
                    Snackbar.make(root, "Product updated", Snackbar.LENGTH_LONG).show();
                    if (getActivity() != null) {
                        getActivity().onBackPressed();
                    }
                } catch (IOException e) {
                    Snackbar.make(root, "Error updating product", Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.RED)
                            .show();
                }
            }
        });

        return root;
    }
}
