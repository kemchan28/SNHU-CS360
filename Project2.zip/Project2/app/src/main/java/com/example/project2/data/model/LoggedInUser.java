package com.example.project2.data.model;

public class LoggedInUser {
    private String userId;
    private String displayName;
    private String lastLoginTime;

    public LoggedInUser(String userId, String displayName, String lastLoginTime){
        this.userId = userId;
        this.displayName = displayName;
        this.lastLoginTime = lastLoginTime;
    }

    public String getUserId(){
        return userId;
    }

    public String getDisplayName(){
        return displayName;
    }

    public String getLastLoginTime(){
        return lastLoginTime;
    }
}
