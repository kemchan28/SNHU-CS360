package com.example.project2.data.helpers;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.project2.data.model.SqlDbContract;

import java.util.ArrayList;
import java.util.HashMap;

public class SqlDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_NAME = "Inventory.db";

    public SqlDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(SqlCommands.CREATE_AUTH_TABLE);
        db.execSQL(SqlCommands.CREATE_INV_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(SqlCommands.CREATE_DB_SCHEMA);
    }

    public static HashMap GetFirst(Cursor cursor){
        int colCount = cursor.getColumnCount();
        HashMap row = new HashMap();

        if(cursor != null && cursor.moveToNext()){
            for(int i = 0; i < colCount; i++) {
                switch (cursor.getType(i)) {
                    case Cursor.FIELD_TYPE_INTEGER:
                        row.put(cursor.getColumnName(i), cursor.getInt(i));
                        break;
                    case Cursor.FIELD_TYPE_FLOAT:
                        row.put(cursor.getColumnName(i), cursor.getFloat(i));
                        break;
                    case Cursor.FIELD_TYPE_STRING:
                        row.put(cursor.getColumnName(i), cursor.getString(i));
                        break;
                }
            }
        }
        return row;
    }

    public static ArrayList<HashMap> GetAll(Cursor cursor){
        int colCount = cursor.getColumnCount();
        ArrayList<HashMap> rows = new ArrayList<HashMap>();

        if (cursor != null) {
            while (cursor.moveToNext()){
                HashMap row = new HashMap(colCount);

                for(int i = 0; i < colCount; i++){
                    switch(cursor.getType(i)){
                        case Cursor.FIELD_TYPE_INTEGER:
                            row.put(cursor.getColumnName(i), cursor.getInt(i));
                            break;
                        case Cursor.FIELD_TYPE_FLOAT:
                            row.put(cursor.getColumnName(i), cursor.getFloat(i));
                            break;
                        case Cursor.FIELD_TYPE_STRING:
                            row.put(cursor.getColumnName(i), cursor.getString(i));
                            break;
                    }
                }
                rows.add(row);
            }
        }
        return rows;
    }
}