package com.example.project2.ui.home;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.project2.R;
import com.example.project2.data.InventoryDataSource;
import com.example.project2.data.Result;

import java.io.IOException;

public class AddDataViewModel extends ViewModel {
    private MutableLiveData<AddDataFormState> addDataFormState = new MutableLiveData<>();
    private InventoryDataSource dataSource;

    public AddDataViewModel() {
    }

    LiveData<AddDataFormState> getAddDataFormState() {
        return addDataFormState;
    }

    public void InitializeDataProvider(Context context) {
        dataSource = new InventoryDataSource(context);
    }

    public void addDataDataChanged(String name, String type, String count) {
        if (!isStringValid(name)) {
            addDataFormState.setValue(new AddDataFormState(R.string.invalid_name, null, null));

        } else if (!isStringValid(type)) {
            addDataFormState.setValue(new AddDataFormState(null, R.string.invalid_type, null));

        } else if (!isStringValid(count)) {
            addDataFormState.setValue(new AddDataFormState(null, null, R.string.invalid_count));

        } else {
            addDataFormState.setValue(new AddDataFormState(true));
        }
    }

    public void addProduct(String name, String type, String count) throws IOException {
        try {
            dataSource.insertInventoryData(name, type, Integer.parseInt(count));
        } catch (Exception e) {
            throw new IOException("Error adding product",e);
        }
    }

    private boolean isStringValid(String string) {
        return string != null && string.trim().length() > 3;
    }

    private boolean isValidNumber(String sys){
        try{
            int i = Integer.parseInt(sys);
            return true;
        }catch(NumberFormatException e){
            return false;
        }
    }
}