package com.example.project2.ui.home;

import android.content.Context;
import android.database.Cursor;
import android.provider.BaseColumns;

import androidx.lifecycle.ViewModel;

import com.example.project2.data.InventoryDataSource;
import com.example.project2.data.helpers.SqlDbHelper;
import com.example.project2.data.model.SqlDbContract;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.IOException;

public class HomeViewModel extends ViewModel {
    private InventoryDataSource dataSource;

    public HomeViewModel() {
    }

    public void InitializeDataProvider(Context context){
        dataSource = new InventoryDataSource(context);
    }

    public ArrayList<HashMap> GetRecords() {
        String[] projection ={
                BaseColumns._ID,
                SqlDbContract.InventoryEntry.COLUMN_NAME_NAME,
                SqlDbContract.InventoryEntry.COLUMN_NAME_TYPE,
                SqlDbContract.InventoryEntry.COLUMN_NAME_COUNT
        };
        Cursor cursor = dataSource.queryInventoryDatabase(projection, null, null, null);
        return SqlDbHelper.GetAll(cursor);
    }
}
