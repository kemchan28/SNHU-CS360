package com.example.project2.data;

// This file is no longer used. Content moved to Result.java
