package com.example.project2.data;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project2.R;
import com.example.project2.ui.home.HomeFragmentDirections;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RecycleDataAdapter extends RecyclerView.Adapter<RecycleDataAdapter.ViewHolder>{
    private List<HashMap> data;
    private LayoutInflater inflater;
    private ItemClickListener itemClickListener;
    private InventoryDataSource dataSource;

    public RecycleDataAdapter(Context context, List<HashMap> data){
        this.inflater = LayoutInflater.from(context);
        this.data = data;
        this.dataSource = new InventoryDataSource(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        HashMap row = data.get(position);
        Iterator it = row.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();

            switch (entry.getKey().toString()) {
                case "id":
                    holder.id.setText(entry.getValue().toString());
                    break;
                case "name":
                    holder.name.setText(entry.getValue().toString());
                    break;
                case "type":
                    holder.type.setText(entry.getValue().toString());
                    break;
                case "count":
                    holder.count.setText(entry.getValue().toString());
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public int getItemCount(){
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView id;
        TextView name;
        TextView type;
        TextView count;
        Button deleteButton;

        ViewHolder(View itemView){
            super(itemView);
            id = itemView.findViewById(R.id.id);
            name = itemView.findViewById(R.id.name);
            type = itemView.findViewById(R.id.type);
            count = itemView.findViewById(R.id.count);
            count.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    UpdateCountOnClick(view, id.getText().toString(), count.getText().toString());
                }
            });
            deleteButton = itemView.findViewById(R.id.delete_data);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteButtonOnClick(view, id.getText().toString());
                }
            });

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view){
            if(itemClickListener != null){
                itemClickListener.onItemClick(view, getAdapterPosition());
            }
        }
    }

    public void setClickListener(ItemClickListener itemClickListener){
        this.itemClickListener = itemClickListener;
    }

    public interface ItemClickListener{
        void onItemClick(View view, int position);
    }

    private int CalculatePosition(String id){
        for(int i = 0; i < data.size(); i++){
            HashMap row = data.get(i);
            if(row.get("id").toString().equals(id)){
                return i;
            }
        }
        return -1;
    }

    private void UpdateCountOnClick(View view, String id, String count){
        HomeFragmentDirections.ActionHomeToEditDataFragment action = HomeFragmentDirections.actionHomeToEditDataFragment(id, count);
        Navigation.findNavController(view).navigate(action);
    }

    private void DeleteButtonOnClick(View view, String id){
        dataSource.deleteInventoryData(id);
        int position = CalculatePosition(id);
        if (position != -1) {
            data.remove(position);
            notifyItemRemoved(position);
            Snackbar.make(view, "Data Deleted", Snackbar.LENGTH_LONG).show();
        }
    }
}
