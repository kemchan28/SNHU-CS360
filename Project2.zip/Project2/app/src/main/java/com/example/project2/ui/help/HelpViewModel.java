package com.example.project2.ui.help;

import androidx.lifecycle.ViewModel;

public class HelpViewModel extends ViewModel {
    public HelpViewModel() {
    }
}
