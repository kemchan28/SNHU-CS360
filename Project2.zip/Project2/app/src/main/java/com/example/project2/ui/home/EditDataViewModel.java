package com.example.project2.ui.home;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.project2.R;
import com.example.project2.data.InventoryDataSource;

import java.io.IOException;

public class EditDataViewModel extends ViewModel{
    private MutableLiveData<EditDataFormState> editDataFormState = new MutableLiveData<>();
    private InventoryDataSource dataSource;

    public EditDataViewModel(){
    }
    LiveData<EditDataFormState> getEditDataFormState(){
        return editDataFormState;
    }

    public void InitializeDataProvider(Context context){
        dataSource = new InventoryDataSource(context);
    }

    public void AddDataDataChanged(String count){
        if(!isStringValid(count) || !isValidNumber(count)){
            editDataFormState.setValue(new EditDataFormState(R.string.invalid_count));
        }else{
            editDataFormState.setValue(new EditDataFormState(true));
        }
    }

    public void UpdateRecordCount(String id, String count) throws IOException {
        if (dataSource != null) {
            boolean success = dataSource.updateInventoryData(id, count);
            if (!success) {
                throw new IOException("Error updating product");
            }
        }
    }

    private boolean isStringValid(String string){
        return string != null && !string.trim().isEmpty();
    }

    private boolean isValidNumber(String sys){
        try{
            Integer.parseInt(sys);
            return true;
        }catch(NumberFormatException e){
            return false;
        }
    }
}
