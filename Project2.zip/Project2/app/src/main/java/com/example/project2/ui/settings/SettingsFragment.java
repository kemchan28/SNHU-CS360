package com.example.project2.ui.settings;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.project2.R;
import com.example.project2.data.NotificationTimer;
import com.google.android.material.snackbar.Snackbar;

import java.util.Map;

public class SettingsFragment extends Fragment{
    private SettingsViewModel settingsViewModel;

    private NotificationTimer notificationService;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState){
        settingsViewModel =
                new ViewModelProvider(this).get(SettingsViewModel.class);
        settingsViewModel.InitializeDataProvider(getContext());
        View root = inflater.inflate(R.layout.fragment_settings, container, false);

        notificationService = new NotificationTimer(getContext());

        Switch smsSwitch = root.findViewById(R.id.sms_int_switch);
        smsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    if(ContextCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED &&
                            ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
                                ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED){
                        notificationService.StartThread();
                    } else{
                        requestPermissionLauncher.launch(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS});
                    }
                }else{
                    notificationService.StopThread();
                }
            }
        });

        Button deleteDataButton = root.findViewById(R.id.delete_all_data);
        deleteDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                settingsViewModel.DeleteAllInventoryData();
                Snackbar.make(root, "All data deleted", Snackbar.LENGTH_LONG)
                        .show();
            }
        });

        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            Boolean failedFlag = false;
            for(Map.Entry<String, Boolean> item : result.entrySet()){
                if(item.getValue()){
                    continue;
                }

                Snackbar.make(root, item.getKey() + "Denied", Snackbar.LENGTH_LONG)
                        .setBackgroundTint(Color.RED)
                        .show();
                failedFlag = true;
            }
            if(failedFlag)
                smsSwitch.setChecked(false);

        });

        return root;
    }
}