package com.example.sensormanager;

import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    SensorManager sensor;
    TextView data;
    List<Sensor> myList;

    SensorEventListener listener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float[] sensor_data = event.values;
            data.setText("X: " + sensor_data[0] + "\nY: " + sensor_data[1] + "\nZ: " + sensor_data[2]);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        data = (TextView)findViewById(R.id.sensorData);
        sensor = (SensorManager) getSystemService(SENSOR_SERVICE);
        myList = sensor.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if (myList.size() != 0) {
            sensor.registerListener(listener, (Sensor)myList.get(0), SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            Toast.makeText(getBaseContext(), "No sensor found", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (myList.size() != 0)
            sensor.unregisterListener(listener);
    }
}