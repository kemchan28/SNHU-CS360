package com.example.cs360_5_2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.MessageFormat;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    EditText nameText = findViewById(R.id.main);
    Button buttonSayHello;
    TextView textGreeting = findViewById(R.id.main);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        buttonSayHello = findViewById(R.id.button);
        nameText.addTextChangedListener(this);
        buttonSayHello.setEnabled(false);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if (nameText.getText().toString().matches("")) {
            buttonSayHello.setEnabled(false);
        } else {
            buttonSayHello.setEnabled(true);
        }
    }

    public void SayHello(View view) {
        if (!nameText.getText().toString().matches("")) {
            textGreeting.setText(String.format("Hello %s", nameText.getText().toString()));
        } else {
            textGreeting.setText(R.string.please_enter_your_name);
        }
    }
}